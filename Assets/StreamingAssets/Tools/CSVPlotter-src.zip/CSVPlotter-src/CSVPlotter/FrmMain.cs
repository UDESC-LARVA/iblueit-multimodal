﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Ibit.Core.Util;

namespace ChartCSVBuilder
{
    public partial class Graph : Form
    {
        private string[] _args;

        public Graph(string[] args)
        {
            _args = args;
            InitializeComponent();
        }

        private void OpenFile(string path)
        {
            var file = new FileInfo(path);
            var data = File.ReadAllLines(file.FullName);

            var dataPair =
                data
                .Select(x =>
                {
                    if (x.Equals("time;value", StringComparison.InvariantCultureIgnoreCase))
                        return new KeyValuePair<double, double>(0, 0);

                    var split = x.Split(';');
                    var time = double.Parse(split[0].Replace(",", "."));
                    var value = FlowMath.ToLitresPerMinute(double.Parse(split[1].Replace(",", ".")));
                    time = Math.Round(time, 3);
                    return new KeyValuePair<double, double>(time, FlowMath.ToLitresPerMinute(value + 25));
                })
                .GroupBy(x => x.Key)
                .Select(g => g.First())
                .ToList()
                .Skip(1)
                .ToDictionary(x => x.Key, x => x.Value);

            var timeOffset = dataPair.ElementAt(1).Key;

            for (var i = 1; i < dataPair.Count; i++)
            {
                var pair = dataPair.ElementAt(i);
                chart1.Series[0].Points.AddXY(pair.Key - timeOffset, pair.Value);
            }

            var expPeak = dataPair.Select(x => x.Value).Max();
            var insPeak = dataPair.Select(x => x.Value).Min();

            var expDur = dataPair.Where(x => x.Value > 10).Select(x => x.Key - timeOffset).Aggregate((x, y) => y - x);
            var insDur = dataPair.Where(x => x.Value < -10).Select(x => x.Key - timeOffset).Aggregate((x, y) => y - x);

            var freq = FlowMath.RespiratoryRate(
                new List<KeyValuePair<double, double>>(dataPair).ToDictionary(x => x.Key, x => x.Value),
                (int)(dataPair.Last().Key - timeOffset));

            label3.Text = $"P. EX. {Math.Truncate(expPeak)} L/Min";
            label4.Text = $"P. IN. {Math.Truncate(insPeak)} L/Min";
            label5.Text = $"T. EX. {Math.Truncate(expDur)} seg";
            label6.Text = $"T. IN. {Math.Truncate(insDur)} seg";
            label7.Text = $"FREQ: {Math.Truncate(freq * 60)}/min";

            chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

            chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -90;
            chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 1;

            if (chart1.Series[0].Points.Count > 1500)
                chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 5;

            this.Text = file.Name;
        }

        private void Graph_Shown(object sender, EventArgs e)
        {
            if (_args.Length > 0)
                OpenFile(_args[0]);
            else
            {
                var dialog = new OpenFileDialog();
                dialog.Filter = "Comma Separeted Value (*.csv)|*.csv";
                var result = dialog.ShowDialog();

                if (dialog.FileName.Length < 1 || result == DialogResult.Cancel)
                    Environment.Exit(0);

                OpenFile(dialog.FileName);
            }
        }

        private void Graph_ResizeEnd(object sender, EventArgs e)
        {
            chart1.Update();
        }
    }
}
