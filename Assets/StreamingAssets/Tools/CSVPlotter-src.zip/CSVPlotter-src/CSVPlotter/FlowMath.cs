﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ibit.Core.Util
{
    public class FlowMath
    {
        public static double RespiratoryRate(Dictionary<double, double> data, int duration)
        {
            var samples = data.ToList();

            double startTime = 0, firstCurveTime = 0, secondCurveTime = 0;
            double quantCycles = 0;

            for (var i = 1; i < samples.Count; i++)
            {
                var actualTime = samples[i].Key;
                var actualValue = samples[i].Value;

                var lastTime = samples[i - 1].Key;

                if (actualValue < -10 || actualValue > 10)
                {
                    if (startTime == 0)
                    {
                        startTime = lastTime;
                    }
                }
                else
                {
                    if (startTime == 0)
                        continue;

                    if (firstCurveTime == 0)
                    {
                        firstCurveTime = actualTime - startTime;
                    }
                    else if (secondCurveTime == 0)
                    {
                        secondCurveTime = actualTime - startTime;
                    }

                    startTime = 0;
                }

                if (firstCurveTime == 0 || secondCurveTime == 0)
                    continue;

                quantCycles++;
                firstCurveTime = 0;
                secondCurveTime = 0;
            }

            //UnityEngine.Debug.Log($"{quantCycles}/{duration} = {quantCycles/duration} ({quantCycles/duration*60} bpm)");

            return quantCycles / duration;
        }

        /// <summary>
        /// Converts m³/s to L/min
        /// </summary>
        private const double LitresPerMinuteConverter = 60000;

        /* Pitaco Measures */
        private const double tubeRadius = 0.018;
        private const double tubeLenght = 0.2;
        private const double airViscosity = 18.2 * 0.000001;

        /// <summary>
        /// Returns the volumetric flow of air in Cubic Meter / Second
        /// </summary>
        /// <param name="differentialPressure">Pressure difference in Pascal (Pa)</param>
        /// <returns></returns>
        private static double Poiseulle(double differentialPressure) =>
            differentialPressure * Math.PI * Math.Pow(tubeRadius, 4) / (8 * airViscosity * tubeLenght);

        /// <summary>
        /// Returns the volumetric flow of air in Litres/Minute
        /// </summary>
        /// <param name="differentialPressure">Pressure difference in Pascal (Pa)</param>
        /// <returns></returns>
        public static double ToLitresPerMinute(double differentialPressure) => Poiseulle(differentialPressure / 1000) * LitresPerMinuteConverter;
    }
}